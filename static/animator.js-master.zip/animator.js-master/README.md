# animator.js

A JavaScript/CSS animation library. Read about it here: http://blog.berniesumption.com/software/animator/
